"use client";
import Link from "next/link";

const BANNERS = [
  { label: "Shirts", slug: "mens-fashion", image: "https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?w=800&q=80", size: "large" },
  { label: "Trousers", slug: "mens-fashion", image: "https://images.unsplash.com/photo-1473966968600-fa801b869a1a?w=800&q=80", size: "small" },
  { label: "Fashion Tops", slug: "womens-fashion", image: "https://images.unsplash.com/photo-1551488831-00ddcb6c6bd3?w=800&q=80", size: "small" },
  { label: "Designer Lane", slug: "womens-fashion", image: "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=800&q=80", size: "small" },
];

export function CategoryBanner() {
  return (
    <section className="w-full py-6">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-[10px]">
        {BANNERS.map((b, i) => (
          <Link key={i} href={`/shop?category=${b.slug}`}
            className="group relative overflow-hidden rounded-2xl bg-gray-100"
            style={{ aspectRatio: i === 0 ? "3/4" : "3/4" }}>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={b.image} alt={b.label}
              className="h-full w-full object-cover transition duration-700 group-hover:scale-105" />
            <div className="absolute inset-0 bg-black/20 group-hover:bg-black/30 transition" />
            <div className="absolute bottom-4 left-4">
              <span className="bg-white text-black text-[10px] font-black uppercase tracking-widest px-3 py-1.5 rounded-sm">
                {b.label}
              </span>
            </div>
          </Link>
        ))}
      </div>
    </section>
  );
}
