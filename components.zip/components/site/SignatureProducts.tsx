"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { ProductCard } from "./ProductCard";

interface Product {
  id: number; name: string; slug: string; thumbnail?: string;
  product_type: string;
  variants?: { price: number; compare_price?: number }[];
}

export function SignatureProducts() {
  const [products, setProducts] = useState<Product[]>([]);

  useEffect(() => {
    fetch(`${process.env.NEXT_PUBLIC_API_URL}/products?per_page=5&sort=price_high`)
      .then(r => r.json())
      .then(d => setProducts((d.data ?? []).slice(0, 5)));
  }, []);

  return (
    <section className="w-full py-6">
      <div className="flex items-center justify-between mb-6 bg-white p-4 rounded-xl shadow-sm border border-gray-100">
        <h2 className="text-xl font-bold text-gray-900 uppercase tracking-tight">Signature Product</h2>
        <Link href="/shop" className="text-sm font-medium text-gray-500 hover:text-black transition">View All →</Link>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-[10px]">
        {products.map(p => (
          <ProductCard key={p.id} id={p.id} name={p.name} slug={p.slug}
            thumbnail={p.thumbnail}
            price={p.variants?.[0]?.price ?? 0}
            compare_price={p.variants?.[0]?.compare_price}
            product_type={p.product_type} />
        ))}
      </div>
    </section>
  );
}
