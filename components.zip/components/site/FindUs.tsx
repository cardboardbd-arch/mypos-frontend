import Link from "next/link";

const STORES = [
  { name: "Headfall - Mirjpur", area: "Dhaka - Garden City", address: "Shop 12, Garden City Shopping Complex, Mirpur 1, Dhaka 1216", phone: "01700-000000" },
  { name: "Sylhet - Garden City", area: "Sylhet - Noya Sarak", address: "Shop 5, Noya Sarak Shopping Center, Sylhet", phone: "01700-000001" },
  { name: "Sylhet - Noya Sarak", area: "Sylhet - Noya Sarak", address: "Shop 8, Noya Sarak, Sylhet City", phone: "01700-000002" },
  { name: "Kumarpot Point, Sylhet", area: "Sylhet - Kumarpot", address: "Kumarpot Point Shopping Mall, Sylhet", phone: "01700-000003" },
];

export function FindUs() {
  return (
    <section className="w-full py-8">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-bold uppercase tracking-tight">Find Us</h2>
        <Link href="/stores" className="text-sm font-medium text-gray-500 hover:text-black transition">View All →</Link>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-[10px]">
        {STORES.map((store, i) => (
          <div key={i} className="border border-gray-100 rounded-2xl p-5 hover:shadow-md transition">
            <div className="w-10 h-10 bg-gray-100 rounded-xl flex items-center justify-center mb-3 text-lg">📍</div>
            <p className="font-black text-sm text-gray-900">{store.name}</p>
            <p className="text-xs text-gray-400 mt-1">{store.area}</p>
            <p className="text-xs text-gray-500 mt-2 leading-relaxed">{store.address}</p>
            <p className="text-xs font-bold text-black mt-2">{store.phone}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
