import Link from "next/link";

export function BigDealsBanner() {
  return (
    <section className="w-full py-4">
      <Link href="/shop?sale=true">
        <div className="bg-[#f5a623] hover:bg-[#e09520] transition rounded-2xl px-8 py-6 flex flex-col md:flex-row items-center justify-between gap-4 cursor-pointer">
          <div>
            <p className="text-2xl md:text-3xl font-black uppercase tracking-tight text-black">
              BIG DEALS চলছে 🔥
            </p>
            <p className="text-sm font-bold text-black/70 mt-1">PRICES GONE EVEN HIGH →</p>
          </div>
          <div className="bg-black text-white px-8 py-3 text-sm font-black uppercase tracking-widest rounded-sm hover:bg-gray-800 transition">
            Shop Deals →
          </div>
        </div>
      </Link>
    </section>
  );
}
