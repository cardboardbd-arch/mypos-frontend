"use client";

import Link from "next/link";

const features = [
  { icon: "🏷️", label: "100+ BRANDS" },
  { icon: "🚚", label: "FREE DELIVERY" },
  { icon: "💬", label: "CUSTOMER SERVICE" },
  { icon: "🔒", label: "SECURE PAYMENT" },
];

const quickLinks = [
  ["Home", "/"],
  ["Shop", "/shop"],
  ["Categories", "/categories"],
  ["Brands", "/brands"],
  ["New Arrivals", "/shop?sort=new"],
  ["About Us", "/about"],
  ["FAQ", "/faq"],
];

const socialLinks: { label: string; svg: string }[] = [
  {
    label: "Facebook",
    svg: `<svg viewBox="0 0 24 24" fill="currentColor" width="14" height="14"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg>`,
  },
  {
    label: "Instagram",
    svg: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><rect x="2" y="2" width="20" height="20" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none"/></svg>`,
  },
  {
    label: "Twitter",
    svg: `<svg viewBox="0 0 24 24" fill="currentColor" width="14" height="14"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>`,
  },
  {
    label: "YouTube",
    svg: `<svg viewBox="0 0 24 24" fill="currentColor" width="14" height="14"><path d="M22.54 6.42a2.78 2.78 0 0 0-1.95-1.96C18.88 4 12 4 12 4s-6.88 0-8.59.46a2.78 2.78 0 0 0-1.95 1.96A29 29 0 0 0 1 12a29 29 0 0 0 .46 5.58A2.78 2.78 0 0 0 3.41 19.54C5.12 20 12 20 12 20s6.88 0 8.59-.46a2.78 2.78 0 0 0 1.95-1.96A29 29 0 0 0 23 12a29 29 0 0 0-.46-5.58zM9.75 15.02V8.98L15.5 12l-5.75 3.02z"/></svg>`,
  },
];

const customerLinks = [
  ["My Account", "/profile"],
  ["Track Order", "/track-order"],
  ["Wishlist", "/wishlist"],
  ["Return Policy", "/return-policy"],
  ["Contact Us", "/contact"],
];

export function Footer() {
  return (
    <footer className="bg-black text-white mt-8">
      {/* Red feature bar */}
      <div className="bg-[#cc0000]">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 divide-x divide-red-700">
            {features.map((f) => (
              <div
                key={f.label}
                className="flex items-center justify-center gap-2 py-3 px-4"
              >
                <span className="text-lg">{f.icon}</span>
                <span className="text-xs font-bold tracking-widest text-white">
                  {f.label}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Main footer */}
      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Brand col */}
          <div className="space-y-4">
            <div>
              <p className="text-xl font-black tracking-tight">PIXELIZZ</p>
              <p className="text-[9px] tracking-[0.25em] text-gray-400 uppercase mt-0.5">
                Business OS
              </p>
            </div>
            <p className="text-sm text-gray-400 leading-relaxed">
              Your one-stop destination for quality products at the best prices.
              Shop smart, live better.
            </p>
            <div className="flex items-center gap-3">
              {socialLinks.map(({ label, svg }) => (
                <a
                  key={label}
                  href="#"
                  aria-label={label}
                  className="w-8 h-8 rounded-full border border-gray-700 flex items-center justify-center text-gray-400 hover:border-white hover:text-white transition-colors"
                  dangerouslySetInnerHTML={{ __html: svg }}
                />
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-sm font-bold uppercase tracking-widest text-gray-300 mb-4">
              Quick Links
            </h3>
            <ul className="space-y-2">
              {quickLinks.map(([label, href]) => (
                <li key={href}>
                  <Link
                    href={href}
                    className="text-sm text-gray-400 hover:text-white transition-colors"
                  >
                    {label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Customer Service */}
          <div>
            <h3 className="text-sm font-bold uppercase tracking-widest text-gray-300 mb-4">
              Customer Service
            </h3>
            <ul className="space-y-2">
              {customerLinks.map(([label, href]) => (
                <li key={href}>
                  <Link
                    href={href}
                    className="text-sm text-gray-400 hover:text-white transition-colors"
                  >
                    {label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h3 className="text-sm font-bold uppercase tracking-widest text-gray-300 mb-4">
              Newsletter
            </h3>
            <p className="text-sm text-gray-400 mb-4">
              Subscribe to get the latest deals and product updates.
            </p>
            <form
              onSubmit={(e) => e.preventDefault()}
              className="flex flex-col gap-2"
            >
              <input
                type="email"
                placeholder="Your email address"
                className="w-full px-4 py-2.5 text-sm bg-gray-900 border border-gray-700 rounded-lg text-white placeholder-gray-500 outline-none focus:border-gray-400 transition-colors"
              />
              <button
                type="submit"
                className="w-full py-2.5 bg-white text-black text-sm font-semibold rounded-lg hover:bg-gray-200 transition-colors"
              >
                Subscribe
              </button>
            </form>
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-gray-800">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-4 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-gray-500">
          <p>© 2026 Pixelizz. All rights reserved.</p>
          <div className="flex items-center gap-4">
            <Link href="/privacy" className="hover:text-gray-300 transition-colors">Privacy Policy</Link>
            <Link href="/terms" className="hover:text-gray-300 transition-colors">Terms of Service</Link>
            <Link href="/return-policy" className="hover:text-gray-300 transition-colors">Return Policy</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
