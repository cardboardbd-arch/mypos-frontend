"use client";
import { useEffect, useState, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import { Nav } from "@/components/site/Nav";
import { Footer } from "@/components/site/Footer";
import { ProductCard } from "@/components/site/ProductCard";
import { Search, X, ChevronDown } from "lucide-react";

interface Product {
  id: number; name: string; slug: string; thumbnail?: string;
  product_type: string;
  category?: { name: string; slug: string };
  brand?: { name: string; slug: string };
  variants?: { price: number; compare_price?: number }[];
}
interface Category { id: number; name: string; slug: string; }
interface Brand { id: number; name: string; slug: string; }

function ShopContent() {
  const searchParams = useSearchParams();
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [brands, setBrands] = useState<Brand[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState(searchParams.get("q") ?? "");
  const [selectedCategory, setSelectedCategory] = useState(searchParams.get("category") ?? "");
  const [selectedBrand, setSelectedBrand] = useState(searchParams.get("brand") ?? "");
  const [sortBy, setSortBy] = useState("newest");
  const BASE = process.env.NEXT_PUBLIC_API_URL;

  useEffect(() => {
    fetch(`${BASE}/categories`).then(r => r.json()).then(d => setCategories(d.data ?? d));
    fetch(`${BASE}/brands`).then(r => r.json()).then(d => setBrands(d.data ?? d));
  }, []);

  useEffect(() => {
    setLoading(true);
    const params = new URLSearchParams();
    if (search) params.set("search", search);
    if (selectedCategory) params.set("category", selectedCategory);
    if (selectedBrand) params.set("brand", selectedBrand);
    if (sortBy) params.set("sort", sortBy);
    fetch(`${BASE}/products?${params.toString()}`)
      .then(r => r.json())
      .then(d => { setProducts(d.data ?? []); setLoading(false); });
  }, [search, selectedCategory, selectedBrand, sortBy]);

  const clearFilters = () => { setSearch(""); setSelectedCategory(""); setSelectedBrand(""); setSortBy("newest"); };
  const hasFilters = search || selectedCategory || selectedBrand;

  return (
    <>
      <Nav />

      {/* Page Header */}
      <div className="bg-gray-50 border-b border-gray-100 py-6">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-black uppercase tracking-tight">Shop</h1>
            <p className="text-xs text-gray-400 mt-1">{products.length} products found</p>
          </div>
          {/* Sort */}
          <select value={sortBy} onChange={e => setSortBy(e.target.value)}
            className="border border-gray-200 rounded-xl px-4 py-2 text-sm focus:outline-none focus:border-black bg-white">
            <option value="newest">Newest First</option>
            <option value="price_low">Price: Low to High</option>
            <option value="price_high">Price: High to Low</option>
            <option value="name">Name A-Z</option>
          </select>
        </div>
      </div>

      <div className="bg-white">
      <div className="max-w-[1400px] mx-auto px-6 lg:px-10 py-8">
        <div className="flex gap-8">

          {/* LEFT SIDEBAR */}
          <aside className="hidden lg:block w-64 shrink-0">

            {/* Search */}
            <div className="mb-6">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                <input type="text" placeholder="Search products..."
                  value={search} onChange={e => setSearch(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-black transition" />
              </div>
            </div>

            {/* Clear Filters */}
            {hasFilters && (
              <button onClick={clearFilters}
                className="flex items-center gap-1 text-xs text-red-500 hover:text-red-700 mb-4 font-bold">
                <X className="h-3 w-3" /> Clear All Filters
              </button>
            )}

            {/* Category Widget */}
            <div className="mb-6 border border-gray-100 rounded-2xl overflow-hidden">
              <div className="flex items-center justify-between px-4 py-3 bg-gray-50 border-b border-gray-100">
                <h3 className="text-xs font-black uppercase tracking-wider">Categories</h3>
                <ChevronDown className="h-4 w-4 text-gray-400" />
              </div>
              <div className="p-3 space-y-1 bg-white">
                <button onClick={() => setSelectedCategory("")}
                  className={`w-full text-left px-3 py-2 text-sm rounded-lg transition font-medium
                    ${!selectedCategory ? 'bg-black text-white' : 'hover:bg-gray-50 text-gray-700'}`}>
                  All Categories
                </button>
                {categories.map(c => (
                  <button key={c.id} onClick={() => setSelectedCategory(c.slug)}
                    className={`w-full text-left px-3 py-2 text-sm rounded-lg transition
                      ${selectedCategory === c.slug ? 'bg-black text-white font-medium' : 'hover:bg-gray-50 text-gray-600'}`}>
                    {c.name}
                  </button>
                ))}
              </div>
            </div>

            {/* Brand Widget */}
            <div className="mb-6 border border-gray-100 rounded-2xl overflow-hidden">
              <div className="flex items-center justify-between px-4 py-3 bg-gray-50 border-b border-gray-100">
                <h3 className="text-xs font-black uppercase tracking-wider">Brands</h3>
                <ChevronDown className="h-4 w-4 text-gray-400" />
              </div>
              <div className="p-3 space-y-1">
                <button onClick={() => setSelectedBrand("")}
                  className={`w-full text-left px-3 py-2 text-sm rounded-lg transition font-medium
                    ${!selectedBrand ? 'bg-black text-white' : 'hover:bg-gray-50 text-gray-700'}`}>
                  All Brands
                </button>
                {brands.map(b => (
                  <button key={b.id} onClick={() => setSelectedBrand(b.slug)}
                    className={`w-full text-left px-3 py-2 text-sm rounded-lg transition
                      ${selectedBrand === b.slug ? 'bg-black text-white font-medium' : 'hover:bg-gray-50 text-gray-600'}`}>
                    {b.name}
                  </button>
                ))}
              </div>
            </div>

            {/* Price Range Widget */}
            <div className="mb-6 border border-gray-100 rounded-2xl overflow-hidden">
              <div className="flex items-center justify-between px-4 py-3 bg-gray-50 border-b border-gray-100">
                <h3 className="text-xs font-black uppercase tracking-wider">Price Range</h3>
                <ChevronDown className="h-4 w-4 text-gray-400" />
              </div>
              <div className="p-4 space-y-2 bg-white">
                {[
                  { label: "Under Tk 500", value: "0-500" },
                  { label: "Tk 500 - 1,000", value: "500-1000" },
                  { label: "Tk 1,000 - 2,000", value: "1000-2000" },
                  { label: "Tk 2,000 - 5,000", value: "2000-5000" },
                  { label: "Above Tk 5,000", value: "5000-99999" },
                ].map(p => (
                  <label key={p.value} className="flex items-center gap-2 cursor-pointer text-sm text-gray-600 hover:text-black">
                    <input type="radio" name="price" value={p.value} className="accent-black" />
                    {p.label}
                  </label>
                ))}
              </div>
            </div>

            {/* Product Type Widget */}
            <div className="border border-gray-100 rounded-2xl overflow-hidden">
              <div className="flex items-center justify-between px-4 py-3 bg-gray-50 border-b border-gray-100">
                <h3 className="text-xs font-black uppercase tracking-wider">Product Type</h3>
                <ChevronDown className="h-4 w-4 text-gray-400" />
              </div>
              <div className="p-3 space-y-1 bg-white">
                {["Simple", "Variable", "Bundle", "Digital"].map(type => (
                  <label key={type} className="flex items-center gap-2 px-3 py-2 cursor-pointer text-sm text-gray-600 hover:text-black rounded-lg hover:bg-gray-50">
                    <input type="checkbox" className="accent-black" />
                    {type}
                  </label>
                ))}
              </div>
            </div>
          </aside>

          {/* RIGHT CONTENT */}
          <div className="flex-1 min-w-0">

            {/* Active Filter Tags */}
            {hasFilters && (
              <div className="flex flex-wrap gap-2 mb-4">
                {selectedCategory && (
                  <span className="flex items-center gap-1 bg-black text-white text-xs font-bold px-3 py-1.5 rounded-full">
                    {categories.find(c => c.slug === selectedCategory)?.name}
                    <button onClick={() => setSelectedCategory("")}><X className="h-3 w-3" /></button>
                  </span>
                )}
                {selectedBrand && (
                  <span className="flex items-center gap-1 bg-black text-white text-xs font-bold px-3 py-1.5 rounded-full">
                    {brands.find(b => b.slug === selectedBrand)?.name}
                    <button onClick={() => setSelectedBrand("")}><X className="h-3 w-3" /></button>
                  </span>
                )}
                {search && (
                  <span className="flex items-center gap-1 bg-black text-white text-xs font-bold px-3 py-1.5 rounded-full">
                    &quot;{search}&quot;
                    <button onClick={() => setSearch("")}><X className="h-3 w-3" /></button>
                  </span>
                )}
              </div>
            )}

            {/* Product Grid */}
            {loading ? (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-[10px]">
                {[...Array(8)].map((_, i) => (
                  <div key={i} className="animate-pulse bg-gray-100 rounded-2xl aspect-[4/5]" />
                ))}
              </div>
            ) : products.length === 0 ? (
              <div className="text-center py-20">
                <p className="text-gray-400 text-sm">No products found.</p>
                <button onClick={clearFilters} className="mt-4 text-xs font-bold underline">Clear filters</button>
              </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-[10px]">
                {products.map(p => (
                  <ProductCard key={p.id} id={p.id} name={p.name} slug={p.slug}
                    thumbnail={p.thumbnail}
                    price={p.variants?.[0]?.price ?? 0}
                    compare_price={p.variants?.[0]?.compare_price}
                    product_type={p.product_type} />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
      </div>
      <Footer />
    </>
  );
}

export default function ShopPage() {
  return (
    <Suspense fallback={<div className="min-h-screen flex items-center justify-center text-gray-400 text-sm">Loading...</div>}>
      <ShopContent />
    </Suspense>
  );
}
