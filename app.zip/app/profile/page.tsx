"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Nav } from "@/components/site/Nav";
import { Footer } from "@/components/site/Footer";
import { getProfile, logoutCustomer, getToken, removeToken } from "@/lib/auth";
import { User, Package, MapPin, LogOut } from "lucide-react";

export default function ProfilePage() {
  const router = useRouter();
  const [customer, setCustomer] = useState<Record<string, string> | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = getToken();
    if (!token) { router.push("/login"); return; }
    getProfile(token).then(data => {
      if (data.id) setCustomer(data);
      else { removeToken(); router.push("/login"); }
      setLoading(false);
    });
  }, [router]);

  const handleLogout = async () => {
    const token = getToken();
    if (token) await logoutCustomer(token);
    removeToken();
    router.push("/");
  };

  if (loading) return (
    <>
      <Nav />
      <div className="min-h-[60vh] flex items-center justify-center">
        <div className="animate-pulse text-gray-400 text-sm">Loading profile...</div>
      </div>
      <Footer />
    </>
  );

  return (
    <>
      <Nav />
      <div className="max-w-[1400px] mx-auto px-6 lg:px-10 py-10">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">

          {/* Sidebar */}
          <aside className="space-y-2">
            <div className="bg-black text-white rounded-2xl p-6 text-center">
              <div className="w-16 h-16 bg-white/10 rounded-full flex items-center justify-center mx-auto mb-3">
                <User className="h-8 w-8 text-white" />
              </div>
              <p className="font-black text-lg">{customer?.name}</p>
              <p className="text-xs text-white/60 mt-1">{customer?.phone}</p>
            </div>
            <nav className="space-y-1">
              {[
                { icon: User, label: "My Profile", active: true },
                { icon: Package, label: "My Orders" },
                { icon: MapPin, label: "Addresses" },
              ].map((item, i) => (
                <button key={i}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold transition
                    ${item.active ? "bg-gray-100 text-black" : "text-gray-500 hover:bg-gray-50"}`}>
                  <item.icon className="h-4 w-4" />
                  {item.label}
                </button>
              ))}
              <button onClick={handleLogout}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold text-red-500 hover:bg-red-50 transition">
                <LogOut className="h-4 w-4" />
                Sign Out
              </button>
            </nav>
          </aside>

          {/* Main Content */}
          <div className="lg:col-span-3 space-y-6">
            <div className="border border-gray-100 rounded-2xl p-6">
              <h2 className="text-sm font-black uppercase tracking-wider mb-5">Profile Information</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                <div><p className="text-xs text-gray-400 uppercase tracking-wider">Full Name</p><p className="font-bold mt-1">{customer?.name}</p></div>
                <div><p className="text-xs text-gray-400 uppercase tracking-wider">Phone</p><p className="font-bold mt-1">{customer?.phone}</p></div>
                <div><p className="text-xs text-gray-400 uppercase tracking-wider">Email</p><p className="font-bold mt-1">{customer?.email ?? "—"}</p></div>
                <div><p className="text-xs text-gray-400 uppercase tracking-wider">City</p><p className="font-bold mt-1">{customer?.city ?? "—"}</p></div>
                <div className="md:col-span-2"><p className="text-xs text-gray-400 uppercase tracking-wider">Address</p><p className="font-bold mt-1">{customer?.address ?? "—"}</p></div>
              </div>
            </div>

            <div className="border border-gray-100 rounded-2xl p-6">
              <h2 className="text-sm font-black uppercase tracking-wider mb-4">Recent Orders</h2>
              <div className="text-center py-8 text-gray-400 text-sm">
                <Package className="h-10 w-10 mx-auto mb-3 text-gray-200" />
                No orders yet.
              </div>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
}
