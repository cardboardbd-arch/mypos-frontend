"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { Nav } from "@/components/site/Nav";
import { Footer } from "@/components/site/Footer";
import { ShoppingCart, Heart, ChevronRight } from "lucide-react";
import { useCart } from "@/lib/cart";

interface Variant {
  id: number;
  sku: string;
  price: number;
  compare_price?: number;
  stock_quantity: number;
  attributes?: Record<string, string>;
}

interface Product {
  id: number;
  name: string;
  slug: string;
  sku?: string;
  description?: string;
  short_description?: string;
  thumbnail?: string;
  product_type: string;
  category?: { name: string; slug: string };
  brand?: { name: string; slug: string };
  variants: Variant[];
  images?: { image_path: string }[];
}

export default function ProductDetailPage() {
  const { slug } = useParams();
  const router = useRouter();
  const { addToCart } = useCart();
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedVariant, setSelectedVariant] = useState<Variant | null>(null);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [quantity, setQuantity] = useState(1);

  function handleAddToCart() {
    if (!product || !selectedVariant) return;
    addToCart({
      variantId: selectedVariant.id,
      productId: product.id,
      name: product.name,
      slug: product.slug,
      sku: selectedVariant.sku,
      price: selectedVariant.price,
      compare_price: selectedVariant.compare_price,
      thumbnail: product.thumbnail,
      attributes: selectedVariant.attributes,
    }, quantity);
  }

  function handleBuyNow() {
    handleAddToCart();
    router.push("/checkout");
  }

  useEffect(() => {
    fetch(`${process.env.NEXT_PUBLIC_API_URL}/products/${slug}`)
      .then((r) => r.json())
      .then((data) => {
        setProduct(data);
        setSelectedVariant(data.variants?.[0] ?? null);
        setSelectedImage(data.thumbnail ?? null);
        setLoading(false);
      });
  }, [slug]);

  if (loading)
    return (
      <>
        <Nav />
        <div className="min-h-[60vh] flex items-center justify-center">
          <div className="animate-pulse text-gray-400 text-sm">Loading...</div>
        </div>
        <Footer />
      </>
    );

  if (!product)
    return (
      <>
        <Nav />
        <div className="min-h-[60vh] flex items-center justify-center">
          <p className="text-gray-500">Product not found.</p>
        </div>
        <Footer />
      </>
    );

  const price = selectedVariant?.price ?? 0;
  const comparePrice = selectedVariant?.compare_price;
  const discount = comparePrice
    ? Math.round(((comparePrice - price) / comparePrice) * 100)
    : null;

  return (
    <>
      <Nav />
      <div className="max-w-[1400px] mx-auto px-6 lg:px-10 py-8">

        {/* Breadcrumb */}
        <nav className="flex items-center gap-2 text-xs text-gray-400 mb-8">
          <a href="/" className="hover:text-black transition">
            Home
          </a>
          <ChevronRight className="h-3 w-3" />
          {product.category && (
            <>
              <a
                href={`/shop?category=${product.category.slug}`}
                className="hover:text-black transition"
              >
                {product.category.name}
              </a>
              <ChevronRight className="h-3 w-3" />
            </>
          )}
          <span className="text-gray-700 font-medium line-clamp-1">
            {product.name}
          </span>
        </nav>

        {/* Main Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-16">

          {/* Left: Images */}
          <div className="flex flex-col gap-3">
            <div className="aspect-square rounded-2xl overflow-hidden bg-gray-100">
              {selectedImage ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  src={selectedImage}
                  alt={product.name}
                  className="h-full w-full object-cover"
                />
              ) : (
                <div className="h-full w-full flex items-center justify-center">
                  <ShoppingCart className="h-16 w-16 text-gray-300" />
                </div>
              )}
            </div>

            {/* Thumbnail gallery */}
            {product.images && product.images.length > 0 && (
              <div className="flex gap-2 overflow-x-auto">
                {product.images.map((img, i) => (
                  <button
                    key={i}
                    onClick={() => setSelectedImage(img.image_path)}
                    className={`shrink-0 w-20 h-20 rounded-lg overflow-hidden border-2 transition ${
                      selectedImage === img.image_path
                        ? "border-black"
                        : "border-transparent"
                    }`}
                  >
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={img.image_path}
                      alt=""
                      className="h-full w-full object-cover"
                    />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Right: Info */}
          <div className="flex flex-col gap-5">
            {product.brand && (
              <span className="text-xs font-bold uppercase tracking-widest text-gray-400">
                {product.brand.name}
              </span>
            )}

            <h1 className="text-2xl md:text-3xl font-bold text-gray-900 leading-tight">
              {product.name}
            </h1>

            {/* Price */}
            <div className="flex items-center gap-3">
              <span className="text-2xl font-black text-gray-900">
                Tk {price.toLocaleString()}
              </span>
              {comparePrice && (
                <span className="text-base text-gray-400 line-through">
                  Tk {comparePrice.toLocaleString()}
                </span>
              )}
              {discount && (
                <span className="bg-red-500 text-white text-xs font-bold px-2 py-1 rounded">
                  {discount}% OFF
                </span>
              )}
            </div>

            {/* Short description */}
            {product.short_description && (
              <p className="text-sm text-gray-500 leading-relaxed">
                {product.short_description}
              </p>
            )}

            {/* Size / Color Selectors */}
            {(() => {
              const sizes = [...new Set(product.variants.map((v) => v.attributes?.size).filter(Boolean))];
              const colors = [...new Set(product.variants.map((v) => v.attributes?.color).filter(Boolean))];

              return (
                <>
                  {sizes.length > 0 && (
                    <div>
                      <p className="text-xs font-bold uppercase tracking-wider text-gray-500 mb-2">
                        Size:{" "}
                        <span className="text-black">
                          {selectedVariant?.attributes?.size}
                        </span>
                      </p>
                      <div className="flex flex-wrap gap-2">
                        {sizes.map((size) => {
                          const variant = product.variants.find(
                            (v) => v.attributes?.size === size
                          );
                          const isSelected =
                            selectedVariant?.attributes?.size === size;
                          const inStock = (variant?.stock_quantity ?? 0) > 0;
                          return (
                            <button
                              key={size}
                              onClick={() =>
                                variant && setSelectedVariant(variant)
                              }
                              disabled={!inStock}
                              className={`w-12 h-12 text-xs font-bold border rounded-lg transition
                                ${isSelected ? "bg-black text-white border-black" : "border-gray-200 hover:border-black"}
                                ${!inStock ? "opacity-30 cursor-not-allowed line-through" : ""}`}
                            >
                              {size}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  {colors.length > 1 && (
                    <div>
                      <p className="text-xs font-bold uppercase tracking-wider text-gray-500 mb-2">
                        Color:{" "}
                        <span className="text-black">
                          {selectedVariant?.attributes?.color}
                        </span>
                      </p>
                      <div className="flex flex-wrap gap-2">
                        {colors.map((color) => {
                          const variant = product.variants.find(
                            (v) => v.attributes?.color === color
                          );
                          const isSelected =
                            selectedVariant?.attributes?.color === color;
                          return (
                            <button
                              key={color}
                              onClick={() =>
                                variant && setSelectedVariant(variant)
                              }
                              className={`px-4 py-2 text-xs font-bold border rounded-lg transition
                                ${isSelected ? "bg-black text-white border-black" : "border-gray-200 hover:border-black"}`}
                            >
                              {color}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </>
              );
            })()}

            {/* Stock */}
            <p
              className={`text-xs font-medium ${
                (selectedVariant?.stock_quantity ?? 0) > 0
                  ? "text-green-600"
                  : "text-red-500"
              }`}
            >
              {(selectedVariant?.stock_quantity ?? 0) > 0
                ? `In Stock (${selectedVariant?.stock_quantity} available)`
                : "Out of Stock"}
            </p>

            {/* Quantity */}
            <div>
              <p className="text-xs font-bold uppercase tracking-wider text-gray-500 mb-2">
                Quantity
              </p>
              <div className="flex items-center border border-gray-200 rounded-lg w-fit">
                <button
                  onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                  className="px-4 py-2 text-lg font-bold hover:bg-gray-50 transition rounded-l-lg"
                >
                  −
                </button>
                <span className="px-6 py-2 text-sm font-bold border-x border-gray-200">
                  {quantity}
                </span>
                <button
                  onClick={() => setQuantity((q) => q + 1)}
                  className="px-4 py-2 text-lg font-bold hover:bg-gray-50 transition rounded-r-lg"
                >
                  +
                </button>
              </div>
            </div>

            {/* Buttons */}
            <div className="flex gap-3 mt-2">
              <button
                onClick={handleBuyNow}
                className="flex-1 bg-black hover:bg-gray-800 text-white py-3 text-sm font-bold uppercase tracking-wider transition rounded-sm flex items-center justify-center gap-2"
              >
                <ShoppingCart className="h-4 w-4" /> Buy Now
              </button>
              <button
                onClick={handleAddToCart}
                className="flex-1 border border-gray-200 hover:border-black text-gray-900 py-3 text-sm font-bold uppercase tracking-wider transition rounded-sm"
              >
                Add to Cart
              </button>
              <button className="border border-gray-200 hover:border-red-400 hover:text-red-400 text-gray-400 px-4 py-3 transition rounded-sm">
                <Heart className="h-5 w-5" />
              </button>
            </div>

            {/* Delivery Info */}
            <div className="border border-gray-100 rounded-xl p-4 space-y-3 mt-2">
              <div className="flex items-center gap-3 text-xs text-gray-600">
                <span className="text-lg">🚚</span>
                <div>
                  <p className="font-bold text-gray-900">Free Delivery</p>
                  <p className="text-gray-400">Dhaka: 1-2 days | Outside: 3-5 days</p>
                </div>
              </div>
              <div className="flex items-center gap-3 text-xs text-gray-600">
                <span className="text-lg">↩️</span>
                <div>
                  <p className="font-bold text-gray-900">Easy Returns</p>
                  <p className="text-gray-400">7 day return policy</p>
                </div>
              </div>
              <div className="flex items-center gap-3 text-xs text-gray-600">
                <span className="text-lg">✅</span>
                <div>
                  <p className="font-bold text-gray-900">100% Authentic</p>
                  <p className="text-gray-400">Genuine product guaranteed</p>
                </div>
              </div>
            </div>

            {/* Description */}
            {product.description && (
              <div className="border-t border-gray-100 pt-5 mt-2">
                <h3 className="text-sm font-bold uppercase tracking-wider mb-3">
                  Product Details
                </h3>
                <p className="text-sm text-gray-500 leading-relaxed">
                  {product.description}
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
}
