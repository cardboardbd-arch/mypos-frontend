import { Nav } from "@/components/site/Nav";
import { Hero } from "@/components/site/Hero";
import { Categories } from "@/components/site/Categories";
import { NewArrivals } from "@/components/site/NewArrivals";
import { SignatureProducts } from "@/components/site/SignatureProducts";
import { CategoryBanner } from "@/components/site/CategoryBanner";
import { DesignerGrid } from "@/components/site/DesignerGrid";
import { BigDealsBanner } from "@/components/site/BigDealsBanner";
import { FindUs } from "@/components/site/FindUs";
import { Footer } from "@/components/site/Footer";

export default function Home() {
  return (
    <main className="bg-white text-gray-900 w-full overflow-x-hidden">
      <Nav />
      <Hero />
      <div className="max-w-[1400px] mx-auto px-6 lg:px-10 space-y-2 py-8">
        <Categories />
        <NewArrivals title="New Arrival" />
        <SignatureProducts />
        <CategoryBanner />
        <DesignerGrid />
        <BigDealsBanner />
        <FindUs />
      </div>
      <Footer />
    </main>
  );
}
